function cesar(clair,decalage) {
  Alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ';
  Malphabet = 'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz';

  //clair = clair.toUpperCase();
  k=parseInt(decalage);
  while(k<0) {k+=26};
   while(k>25) {k-=26};
  chiffre = "";
  for(var count = 0; count < clair.length; count++) {
    alpha = clair.charAt(count);
    if (alpha == " ")
        { chiffre+=" " }
    else {

      if(!isMajuscule(alpha)){
        //console.log(""+count+" minuscule");

        idx = Malphabet.indexOf(alpha);
        if (idx > -1)     // ne (dé)chiffre que les 26 lettres majuscules
        {
          chiffre += Malphabet.charAt(idx+k);
          console.log(""+idx);
        }
      }

      else{
        //console.log(""+count+" majuscule");

        idx = Alphabet.indexOf(alpha);
        if (idx > -1)     // ne (dé)chiffre que les 26 lettres majuscules
        {
          chiffre += Alphabet.charAt(idx+k);
        }
      }
    }
}

  //console.log(Malphabet.length);
  return chiffre;
}

function isMajuscule(texte){
  if(texte.toUpperCase() != texte)
    return false;
  else 
    return true;
}

var form = document.querySelector("form");
//console.log("" + form.elements.textAChiffrer.value);
/*var entre = form.elements.textAChiffrer.value;


// Affichage de la demande de confirmation d'inscription
document.getElementById("textAChiffrer").addEventListener("change", function (e) {
    console.log("Demande de confirmation : " + e.target.checked);
});

console.log("Nombre de champs de saisie : " + form.elements.length); // Affiche 10
console.log(form.elements[0].name);*/

form.addEventListener("submit", function (e) {
  var entre = form.elements.textAChiffrer.value;
  var sortie = form.elements.textChiffre.value;
  var decalage = form.elements.decalage.value;

  form.elements.textChiffre.value = cesar(entre, decalage);

  e.preventDefault();
});