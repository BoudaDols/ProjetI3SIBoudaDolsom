<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Projet I3SI</title>
  <!-- Favicon -->
  <link href="./assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
  <link href="./assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
  <!-- Argon CSS -->
  <link type="text/css" href="./assets/css/argon.css?v=1.0.0" rel="stylesheet">
</head>

<body class="bg-default">
  <div class="main-content">
    <!-- Header -->
    <div class="header bg-gradient-primary py-7 py-lg-8">
      <div class="container">
        <div class="header-body text-center mb-7">
          <div class="row justify-content-center">
            <div class="col-lg-5 col-md-10">
              <h1 class="text-white">Projet I3SI De BOUDA Dolsom</h1>
              <p class="text-lead text-light">Chiffer vos textes avec l'algorithme César</p>
            </div>
          </div>
        </div>
      </div>
      <div class="separator separator-bottom separator-skew zindex-100">
        <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
          <polygon class="fill-default" points="2560 0 2560 100 0 100"></polygon>
        </svg>
      </div>
    </div>
    <!-- Page content -->
    <div class="container mt--8 pb-15">
      <div class="row justify-content-center">
        <div class="col-lg-10 col-md-15">
          <div class="card bg-secondary shadow border-0">
            <div class="card-body px-lg-5 py-lg-5">
              <form name="form" id="form">
                <div class="form-group mb-3">
                  <div class="input-group input-group-alternative">
                    <textarea class="form-control" placeholder="Ecrire un texte ici" id="textAChiffrer" name="textAChiffrer" required></textarea>
                  </div>
                </div>

                <div class="form-group col-lg-3">
                  <label for="exampleFormControlSelect1">Décalage</label>
                  <input class="form-control" id="decalage" name="decalage" type="number">
                </div>
                <div class="row mb-3 col-md-15">
                  <div class="col">
                    <button type="submit" class="btn btn-primary btn-lg">Chiffrer</button>
                  </div>
                  <div class="col">
                    <button type="reset" class="btn btn-primary btn-lg">Reinitialiser</button>
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group input-group-alternative">
                    <textarea class="form-control" placeholder="Resultat" id="textChiffre" name="textChiffre"></textarea>
                  </div>
                </div>
              </form>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </div>
  <!-- Footer -->
  <footer class="py-5">
    <div class="container">
      <div class="row align-items-center justify-content-xl-between">
        <div class="col-xl-6">
          <div class="copyright text-center text-xl-left text-muted">
            &copy; 2020 <a href="#" class="font-weight-bold ml-1" target="_blank">BOUDA Dolsom</a>
          </div>
        </div>
        <div class="col-xl-6">
          <ul class="nav nav-footer justify-content-center justify-content-xl-end">
            <li class="nav-item">
              <a href="#" class="nav-link" target="_blank">BOUDA Dolsom</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="./assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="./assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Argon JS -->
  <script src="./assets/js/argon.js?v=1.0.0"></script>
  <script src="./code.js"></script>
</body>

</html>